import{D as e,On as t,k as n,mt as r,qt as i,v as a}from"./runtime-core.esm-bundler-Blp3D1W4.js";import{M as o,z as s}from"./src-DG51U73Y.js";import{t as c}from"./card-BHkS7t27.js";import{t as l}from"./message-D4EhZrS_.js";var u={additionalInfo:{author:`Your Name`,debug:!0,version:`1.3.10`,versionCode:132},additionalNotes:`This JSON is used for demonstration purposes`,tools:[{description:`Description of Tool 1`,name:`Tool 1`},{description:`Description of Tool 2`,name:`Tool 2`},{description:`Description of Tool 3`,name:`Tool 3`},{description:`Description of Tool 4`,name:`Tool 4`}]},d=JSON.parse(`
  {
	"id": "chatgpt-123",
	"object": "chat.completion",
	"created": 1677652288,
	"model": "gpt-3.5-turbo-0613",
	"system_fingerprint": "fp_44709d6fcb",
	"choices": [{
		"index": 0,
		"message": {
			"role": "assistant",
			"content": "Hello there, how may I assist you today?"
		},
		"finish_reason": "stop"
	}],
	"usage": {
		"prompt_tokens": 9,
		"completion_tokens": 12,
		"total_tokens": 21,
    "debug_mode": true
	},
  "debug": {
    "startAt": "2021-08-01T00:00:00Z",
    "logs": [
      {
        "timestamp": "2021-08-01T00:00:00Z",
        "message": "This is a debug message",
        "extra":[ "extra1", "extra2" ]
      },
      {
        "timestamp": "2021-08-01T00:00:01Z",
        "message": "This is another debug message",
        "extra":[ "extra3", "extra4" ]
      }
    ]
  }
}
  `),f=n({__name:`index`,setup(n){function f(e){l.info(`点击了Key ${e}`)}function p(e){l.info(`点击了Value ${JSON.stringify(e)}`)}function m(e){l.success(`已复制JSON`)}return(n,l)=>(r(),a(t(s),{title:`Json Viewer`,description:`一个渲染 JSON 结构数据的组件，支持复制、展开等，简单易用`},{default:i(()=>[e(t(c),{title:`默认配置`},{default:i(()=>[e(t(o),{value:t(u)},null,8,[`value`])]),_:1}),e(t(c),{title:`可复制、默认展开3层、显示边框、事件处理`,class:`mt-4`},{default:i(()=>[e(t(o),{value:t(d),"expand-depth":3,copyable:``,sort:!1,onKeyClick:f,onValueClick:p,onCopied:m,boxed:``},null,8,[`value`])]),_:1}),e(t(c),{title:`预览模式`,class:`mt-4`},{default:i(()=>[e(t(o),{value:t(d),copyable:``,"preview-mode":``,"show-array-index":!1},null,8,[`value`])]),_:1})]),_:1}))}});export{f as default};